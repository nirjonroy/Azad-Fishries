<?php
/**
 * Single Product Thumbnails
 * This file should need to keep here although it is blank.
 *
 * @see        https://docs.woocommerce.com/document/template-structure/
 * @author     WooThemes
 * @package    WooCommerce/Templates
 * @version    3.6.5
 */