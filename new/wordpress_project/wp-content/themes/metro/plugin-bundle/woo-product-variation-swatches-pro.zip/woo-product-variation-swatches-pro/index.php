<?php

echo "Keep Silent";