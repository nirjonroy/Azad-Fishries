<?php
	defined( 'ABSPATH' ) or die( 'Keep Silent' );
?>

<script type="text/template" id="tmpl-rtwpvs-variation-template">
    {{{ data.price_html }}}
    <div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
